//
//  TextValidatorUtility.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 20/05/21.
//

import Foundation

class TextValidatorUtility {
    
    let sitePasswordPattern =  "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[d$@$!%*?&#])[A-Za-z\\dd$@$!%*?&#]{8,}"
    
    func isValidMobileNumber(number: String) -> Bool {
        
        let invalidCharacters = CharacterSet(charactersIn: "+-()0123456789").inverted
        return (number.rangeOfCharacter(from: invalidCharacters) == nil)
    }
    
    func isValidMPin(pin: String) -> Bool {
        
        let invalidCharacters = CharacterSet(charactersIn: "0123456789").inverted
        return (pin.rangeOfCharacter(from: invalidCharacters) == nil)
    }
    
    func isValidPassword(password: String) -> Bool {
        
        if (password.range(of: sitePasswordPattern, options: .regularExpression) != nil) {
            
            print("Strong password")
            return true
            
        } else {
            
            print("Weak password!!!")
            return false
        }
    }
}
