//
//  ConstantValues.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 20/05/21.
//

import Foundation
import UIKit

enum LoginDetailsKeys: String {
    
    case mobileNumber = "mobileNumber"
    case mPin = "mPin"
}

enum SiteDetailsKey: String {
    
    case url = "url"
    case siteName = "siteName"
    case folder = "folder"
    case userName = "userName"
    case password = "password"
    case notes = "notes"
    case id = "id"
}

enum CornerRadius: CGFloat {
    
    case textField = 5
    case indicator = 3.5
    case siteCell = 14
    case siteCountView = 15
    case signInSignUputton = 4.5
}

enum BorderWidth: CGFloat {
    
    case siteCountView = 0.8
}

enum alertStrings: String {
    
    case success = "REGISTRATION IS SUCCESSFULL"
    case login = " Please login to continue"
    case missingDetails = "Mobile Number/MPin missing"
    case requiredDetails = "Enter required fields"
    case wrongDetails = "Wrong Mobile Number/MPin"
    case checkMpin = "Enter Mpin again"
    case mPinMismatch = "MPin not matching"
    case userExist = "User Already Exist"
}

