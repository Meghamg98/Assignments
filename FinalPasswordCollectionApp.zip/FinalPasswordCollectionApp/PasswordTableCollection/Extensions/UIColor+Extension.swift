//
//  UIColor+Extension.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 20/05/21.
//

import Foundation
import UIKit

extension UIColor {
    
    static func gradientStartColor() -> CGColor {
        
        return UIColor(red:0.13, green:0.73, blue:1, alpha:1).cgColor
    }
    
    static func gradientEndColor() -> CGColor {
        
        return UIColor.blue().cgColor
    }
    
    static func textFieldViewColor() -> CGColor {
        
        return UIColor(red:0.84, green:0.84, blue:0.84, alpha:1).cgColor
    }
    
    static func dropDownViewColor() -> UIColor {
        
        return UIColor.blue()
    }
    
    static func passwordStrengthViewColor() -> UIColor {
        
        return hexToUIColor(hex: "#8BB477")
            //UIColor(red:0.55, green:0.71, blue:0.47, alpha:1)
    }
    
    static func signInSignUpButtonColor() -> UIColor {
        
        return UIColor.blue()
    }
    
    static func blue() -> UIColor {
        
        return  UIColor(red:0.05, green:0.52, blue:1, alpha:1)
    }
    
    static func hexToUIColor(hex: String) -> UIColor {
        
        let r, g, b: CGFloat

        if hex.hasPrefix("#") {
            
            let start = hex.index(hex.startIndex, offsetBy: 1)
            let hexColor = String(hex[start...])

            if hexColor.count == 6 {
                let scanner = Scanner(string: hexColor)
                var hexNumber: UInt64 = 0

                if scanner.scanHexInt64(&hexNumber) {
                    r = CGFloat((hexNumber & 0xff0000) >> 16) / 255
                    g = CGFloat((hexNumber & 0x00ff00) >> 8) / 255
                    b = CGFloat((hexNumber & 0x0000ff)) / 255

                    return UIColor(red: r, green: g, blue: b, alpha: 1.0)
                }
            }
        }
        return UIColor.clear
    }
   
}
