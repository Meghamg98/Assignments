//
//  UIImage+Extension.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 20/05/21.
//

import UIKit

extension UIImage {
    
    static func imageFor(name: String) -> UIImage? {
        
        if let image = UIImage(named: name.lowercased()) {
            
            return image
        } else {
            
            return UIImage(named: "copy2")
        }
    }
}
