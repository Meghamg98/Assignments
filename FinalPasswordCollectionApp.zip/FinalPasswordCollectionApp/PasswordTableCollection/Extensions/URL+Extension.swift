//
//  URL+Extension.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 20/05/21.
//

import Foundation

extension URL {
    
    static func createLoginFilePath() -> URL {
        
        let myFileManager = FileManager.default
        let myFolders = myFileManager.urls(for: .documentDirectory, in: .userDomainMask)
        let myDocumentFolder = myFolders[0]
        let filePath = myDocumentFolder.appendingPathComponent("AppUserDetails")
        return filePath
    }
    
    static func createSiteFilePathForUser(mobileNumber: String) -> URL {
        
        let fileManager = FileManager.default
        let folders = fileManager.urls(for: .documentDirectory, in: .userDomainMask)
        let documentFolder = folders[0]
        let filePath = documentFolder.appendingPathComponent(mobileNumber)
        
        return filePath
    }
}
