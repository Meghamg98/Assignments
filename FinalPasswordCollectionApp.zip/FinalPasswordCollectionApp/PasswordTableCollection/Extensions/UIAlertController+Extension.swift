//
//  UIAlertController+Extension.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 20/05/21.
//

import Foundation
import UIKit

extension UIAlertController {
    
    func alertMessageDisplay(title: String, message: String, buttonTitle: String, parentView: UIViewController) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle:.alert)
        alert.addAction(UIAlertAction(title: buttonTitle, style: .default, handler: nil))
        parentView.present(alert, animated: true)
    }
}
