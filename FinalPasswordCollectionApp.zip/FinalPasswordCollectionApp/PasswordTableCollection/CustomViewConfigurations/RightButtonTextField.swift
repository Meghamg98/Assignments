//
//  RightButtonTextField.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 28/05/21.
//

import UIKit

class RightButtonTextField: SignInSignUpTextFields {
    
    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        
        var newRectangle = bounds
        newRectangle.origin.x = 22
        newRectangle.size.width = newRectangle.size.width - 70
        return newRectangle
    }
    
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        
        var newRectangle = bounds
        newRectangle.origin.x = 22
        newRectangle.size.width = newRectangle.size.width - 70
        return newRectangle
    }
    
}
