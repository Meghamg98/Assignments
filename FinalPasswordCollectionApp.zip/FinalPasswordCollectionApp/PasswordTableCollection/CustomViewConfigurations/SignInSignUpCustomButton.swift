//
//  SignInSignUpCustomButton.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 28/05/21.
//

import UIKit

class SignInSignUpCustomButton: UIButton {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.setCustomButtonProperties()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.setCustomButtonProperties()
    }
    
    func setCustomButtonProperties() {
        
        self.backgroundColor = UIColor.white
        self.layer.cornerRadius = CornerRadius.signInSignUputton.rawValue
        self.titleLabel?.font = UIFont(name: "OpenSans-SemiBold", size:  18.0)
        self.titleLabel?.textColor = UIColor.signInSignUpButtonColor()
        
    }
}
