//
//  CustomBackgroundView.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 28/05/21.
//

import UIKit

class CustomBackgroundView: UIView {

    let loginLayer = CAGradientLayer()
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.setBackgroundViewOfSignInSignUp()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.setBackgroundViewOfSignInSignUp()
    }
    
    func setBackgroundViewOfSignInSignUp() {
        
        loginLayer.colors = [UIColor.gradientStartColor(),UIColor.gradientEndColor()]

        loginLayer.locations = [0, 1]
        loginLayer.startPoint = CGPoint(x: 0.5, y: 0)
        loginLayer.endPoint = CGPoint(x: 0.5, y: 1)
        
        loginLayer.frame = self.bounds
        self.layer.addSublayer(loginLayer)
        self.layer.insertSublayer(loginLayer, at: 0)
        
    }
    
}
