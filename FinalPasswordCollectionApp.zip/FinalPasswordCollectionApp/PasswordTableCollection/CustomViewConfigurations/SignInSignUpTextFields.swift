//
//  SignInSignUpTextFields.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 28/05/21.
//

import UIKit

class SignInSignUpTextFields: UITextField {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.setTextFieldProperties()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.setTextFieldProperties()
    }
    
    func setTextFieldProperties() {
        
        self.textColor = UIColor.gray

        self.backgroundColor = UIColor.white
        self.layer.cornerRadius = CornerRadius.textField.rawValue
        self.font = UIFont(name: "OpenSans-SemiBold", size: 16.0)
    }
    
    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        
        var newRectangle = bounds
        newRectangle.origin.x = 22
        newRectangle.size.width = newRectangle.size.width - 44
        return newRectangle
    }
    
    override func placeholderRect(forBounds bounds: CGRect) -> CGRect {
        
        var newRectangle = bounds
        newRectangle.origin.x = 22
        newRectangle.size.width = newRectangle.size.width - 44
        return newRectangle
    }
    
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        
        var newRectangle = bounds
        newRectangle.origin.x = 22
        newRectangle.size.width = newRectangle.size.width - 44
        return newRectangle
    }
}
