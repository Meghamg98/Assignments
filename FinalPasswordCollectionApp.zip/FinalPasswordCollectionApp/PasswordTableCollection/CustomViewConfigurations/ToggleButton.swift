//
//  ToggleButton.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 28/05/21.
//

import UIKit

class ToggleButton: UIButton {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.toggleButtonProperty()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.toggleButtonProperty()
    }
    
    func toggleButtonProperty() {
        
        self.setImage(UIImage(named: "eye_closed"), for: .normal)
        self.setImage(UIImage(named: "eye_opened"), for: .selected)
        
        self.isSelected = false
        
        //self.addTarget(self, action: #selector(toggle), for: .touchUpInside)
    }
    
    //@objc
    func toggle() {
        
        self.isSelected = !self.isSelected
    }
}
