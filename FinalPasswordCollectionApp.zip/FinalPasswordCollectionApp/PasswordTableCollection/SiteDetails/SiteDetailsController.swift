//
//  SiteDetailsController.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 17/05/21.
//

import UIKit

enum Status {
    case editSiteDetails
    case addSiteDetails
}

protocol AddSiteProtocol {
    
    func addNewSite(url: String, siteName: String, folder: String, userName: String, password: String, notes: String?)
    func editExistingSite(url: String, siteName: String, folder: String, userName: String, password: String, notes: String?, previousFolder: String)
}

class SiteDetailsController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var subView: UIView!

    @IBOutlet weak var urlTextField: UITextField!
    @IBOutlet weak var siteNameTextField: UITextField!
    @IBOutlet weak var sectorTextField: UITextField!
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var sitePasswordTextField: UITextField!
    @IBOutlet weak var notesTextField: UITextView!
    
    @IBOutlet var siteDetailsView: [UIView]!
    
    @IBOutlet weak var editButton: UIBarButtonItem!
    @IBOutlet weak var resetSaveView: UIView!
    @IBOutlet weak var updateView: UIView!

    @IBOutlet weak var selectFolderButton: UIButton!
    @IBOutlet var differentFoldersButton: [UIButton]!
    
    @IBOutlet weak var folderStackView: UIStackView!
    @IBOutlet weak var passwordStrengthView: UIView!
    @IBOutlet weak var passwordStrengthView2: UIView!
    
    var delegate: AddSiteProtocol?
    
    @IBOutlet weak var addSiteLabel: UIBarButtonItem!
    
    var currentStatus: Status = .addSiteDetails
    var currentSite: SiteDetails?
    var previousFolder: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if (currentStatus == .addSiteDetails) {
            
            resetSaveView.isHidden = false
            updateView.isHidden = true
            navigationItem.rightBarButtonItem = nil
            
        } else if (currentStatus == .editSiteDetails) {
            
            urlTextField.text = currentSite?.url
            siteNameTextField.text = currentSite?.siteName
            sectorTextField.text = currentSite?.folder
            userNameTextField.text = currentSite?.userName
            sitePasswordTextField.text = currentSite?.password
            notesTextField.text = currentSite?.notes
            
            urlTextField.isUserInteractionEnabled = false
            siteNameTextField.isUserInteractionEnabled = false
            sectorTextField.isUserInteractionEnabled = false
            userNameTextField.isUserInteractionEnabled = false
            sitePasswordTextField.isUserInteractionEnabled = false
            notesTextField.isUserInteractionEnabled = false
            selectFolderButton.isEnabled = false
            
            updateView.isHidden = true
            resetSaveView.isHidden = true
            
            addSiteLabel.title = "Site Details"
            editButton.isEnabled = true
        }
     
        self.viewConfiguration()
        
        differentFoldersButton.forEach  { (selectedButton) in
            
            selectedButton.isHidden = true
        }

        sitePasswordTextField.isSecureTextEntry = true
        sitePasswordTextField.delegate = self
        sitePasswordTextField.tag = 3
        
    }
 
    func viewConfiguration() {
        
        siteDetailsView.forEach  { (currentView) in
            
            currentView.layer.borderColor = UIColor.textFieldViewColor()
            currentView.layer.borderWidth = 1
            currentView.layer.cornerRadius = 4
        
        }
        
        let tap = UITapGestureRecognizer(target: self, action:  #selector(handle(tapGestureRecognizer:)))
        scrollView.isUserInteractionEnabled = true
        scrollView.addGestureRecognizer(tap)
    }
    
    @objc func handle(tapGestureRecognizer: UITapGestureRecognizer) {
        
        self.animateStackView(hide: true)
    }
    
    func animateStackView(hide: Bool) {
        
        differentFoldersButton.forEach  { (selectedButton) in
            UIView.animate(withDuration: 0.7) {

                selectedButton.isHidden = hide
                selectedButton.layoutIfNeeded()
            }
        }
    }
    
    @IBAction func backButtonClicked(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func eyeButtonClickedHere(_ sender: Any) {
        
        sitePasswordTextField.isSecureTextEntry = !sitePasswordTextField.isSecureTextEntry
    }
    
    @IBAction func editButtonClicked(_ sender: Any) {
        
        navigationItem.rightBarButtonItem = nil
        addSiteLabel.title = "Edit Site"
        updateView.isHidden = false
        
        urlTextField.isUserInteractionEnabled = true
        siteNameTextField.isUserInteractionEnabled = true
        sectorTextField.isUserInteractionEnabled = true
        userNameTextField.isUserInteractionEnabled = true
        sitePasswordTextField.isUserInteractionEnabled = true
        notesTextField.isUserInteractionEnabled = true
        selectFolderButton.isEnabled = true
        
        if let folder = sectorTextField.text {
            previousFolder = folder
        }
        
    }
    
    @IBAction func selectFolderButtonClicked(_ sender: Any) {
        
        differentFoldersButton.forEach  { (selectedButton) in
            UIView.animate(withDuration: 0.7) {

                selectedButton.isHidden = !selectedButton.isHidden
                selectedButton.layoutIfNeeded()
            }
        }
    }
    
    @IBAction func selectedFolder(_ sender: Any) {
        
        if let buttonLabel = (sender as AnyObject).titleLabel?.text {
            sectorTextField.text = buttonLabel
            print("You have selected \(buttonLabel) folder")
            
        }
        
        self.animateStackView(hide: true)
    }
    
    @IBAction func resetbuttonClicked(_ sender: Any) {
        
        urlTextField.text = ""
        siteNameTextField.text = ""
        sectorTextField.text = ""
        userNameTextField.text = ""
        sitePasswordTextField.text = ""
        notesTextField.text = ""
    }
    
    @IBAction func saveButtonClicked(_ sender: Any) {
        
        guard let url = urlTextField.text, !url.isEmpty, let site = siteNameTextField.text, !site.isEmpty,let folder = sectorTextField.text, !folder.isEmpty,let name = userNameTextField.text, !name.isEmpty,let password = sitePasswordTextField.text, !password.isEmpty, let notes = notesTextField.text
        
        else {
            
            UIAlertController().alertMessageDisplay(title: alertStrings.requiredDetails.rawValue, message: "", buttonTitle: "OK", parentView: self)
            
            return
        }
        
        delegate?.addNewSite(url: url, siteName: site, folder: folder, userName: name, password: password, notes: notes)
        
        self.navigationController?.popViewController(animated: true)
        
    }
        
    @IBAction func updateButtonClicked(_ sender: Any) {
        
        guard let url = urlTextField.text, !url.isEmpty, let site = siteNameTextField.text, !site.isEmpty,let folder = sectorTextField.text, !folder.isEmpty,let name = userNameTextField.text, !name.isEmpty,let password = sitePasswordTextField.text, !password.isEmpty
        
        else {
            
            UIAlertController().alertMessageDisplay(title: alertStrings.requiredDetails.rawValue, message: "", buttonTitle: "OK", parentView: self)
    
            return
        }
            
        delegate?.editExistingSite(url: url, siteName: site, folder: folder, userName: name, password: password, notes: notesTextField.text, previousFolder: previousFolder)
                
        self.navigationController?.popViewController(animated: true)
    }
}

extension SiteDetailsController: UITextFieldDelegate {
    
    func textFieldDidChangeSelection(_ textField: UITextField) {
        
        if textField.tag == 3 {
            
            passwordStrengthView.backgroundColor = UIColor.red
            passwordStrengthView2.backgroundColor = UIColor.passwordStrengthViewColor()
            
            self.passwordStrengthView2.alpha = 0
            self.passwordStrengthView.alpha = 0
            
            let validEmail = TextValidatorUtility().isValidPassword(password: sitePasswordTextField.text ?? "")
            
            print(self.passwordStrengthView.frame.size.width)

            if validEmail == true {
                
                UIView.animate(withDuration: 1.0) {
                    
                    self.passwordStrengthView2.alpha = 1
                }
                
            } else {
                
                UIView.animate(withDuration: 1.0) {
    
                    self.passwordStrengthView.alpha = 1
                }
            }
        }
    }
}

/*
 
self.passwordStrengthView.frame = CGRect(x: 20, y: 494.5, width: self.view.frame.width * 1.5, height: self.view.frame.height)
self.passwordStrengthView.frame.size.width = self.passwordStrengthView.frame.size.width + 100

passwordStrengthView.backgroundColor = UIColor.passwordStrengthViewColor()
passwordStrengthView.widthAnchor.constraint(equalToConstant: 200).isActive = true
passwordStrengthView.frame = CGRect(x: 20, y: 494.5, width: self.view.frame.width * 1.5, height: self.view.frame.height)
passwordStrengthView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width + 20.0, height: self.view.frame.height)
self.passwordStrengthView.frame.size.width = self.passwordStrengthView.frame.size.width
self.passwordStrengthView.frame.size.width = self.passwordStrengthView.frame.size.width - 100
passwordStrengthView.backgroundColor = UIColor.red
 */
