//
//  LoginViewModel.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 29/04/21.
//

import Foundation

class LoginViewModel {
    
    var loginArray = [LoginDetails]()
    
    func addUser(mobileNumber: String, mPin: Int) {
        
        loginArray.append(LoginDetails(mobileNumber: mobileNumber, mPin: mPin))
        print("Contact added successfully")
       
    }
    
    func validate(mobileNumber: String, mPin: Int) -> Bool {
        
        for user in loginArray {
            
            let mobileNo = user.mobileNumber
            let pin = user.mPin
            
            if mobileNo == mobileNumber && pin == mPin {
                
                 return true
            }
        }
        return false
    }
    
    func saveLoginDetails() {
        do{
            
            let userLoginData = try
                NSKeyedArchiver.archivedData(withRootObject: self.loginArray, requiringSecureCoding: false)
            try userLoginData.write(to: URL.createLoginFilePath())
            
        } catch {
            print("Path not found")
        }
    }
    
    func loadLoginDetails() {
        
        do{
            
            let userLoginData = try
                Data(contentsOf: URL.createLoginFilePath())
            if let loginArray = try
                NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(userLoginData) as? [LoginDetails] {
                self.loginArray = loginArray
            }
        } catch {
            print("File not found")
        }
    }
}
