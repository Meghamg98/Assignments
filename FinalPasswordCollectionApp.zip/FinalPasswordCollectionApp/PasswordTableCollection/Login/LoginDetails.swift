//
//  LoginDetails.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 29/04/21.
//

import Foundation

class LoginDetails: NSObject, NSCoding {
    
    var mobileNumber: String
    var mPin: Int
    
    init(mobileNumber: String, mPin: Int) {
        self.mobileNumber = mobileNumber
        self.mPin = mPin
    }
    
    func encode(with coder: NSCoder) {
        
        coder.encode(self.mobileNumber, forKey: LoginDetailsKeys.mobileNumber.rawValue)
        coder.encode(self.mPin, forKey: LoginDetailsKeys.mPin.rawValue)
    }
    
    required init?(coder: NSCoder) {
        
        guard let mobileNo = coder.decodeObject(forKey: LoginDetailsKeys.mobileNumber.rawValue) as? String
        else {
            return nil
        }
        
        self.mobileNumber = mobileNo
        self.mPin = coder.decodeInteger(forKey: LoginDetailsKeys.mPin.rawValue)
    }
}
