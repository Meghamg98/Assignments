//
//  SignInController.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 27/04/21.
//

import UIKit

class SignInController: UIViewController {

    @IBOutlet var mainView: UIView!
    @IBOutlet weak var subView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var signInView: UIView!
    @IBOutlet weak var signUpView: UIView!
    
    @IBOutlet var logInTextViews: [UIView]!
    
    @IBOutlet weak var mobileNumberTextField: UITextField!
    @IBOutlet weak var mPinTextField: UITextField!
    @IBOutlet weak var signInIndicatorView: UIView!
    @IBOutlet weak var mobileNumberInSignUpTextField: UITextField!
    @IBOutlet weak var mPinInSignUpTextField: UITextField!
    @IBOutlet weak var reEnteredMPin: SignInSignUpTextFields!
    
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    
    var subViewHeight: CGFloat = 0.0
    var heightNotSet: Bool = false
    
    var loginModel = LoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        loginModel.loadLoginDetails()
        self.viewConfiguration()
        
        mobileNumberTextField.delegate = self
        mobileNumberTextField.tag = 1
        
        mPinTextField.delegate = self
        mPinTextField.tag = 2
        
        mobileNumberInSignUpTextField.delegate = self
        mobileNumberInSignUpTextField.tag = 1
        
        mPinInSignUpTextField.delegate = self
        mPinInSignUpTextField.tag = 2
        
        reEnteredMPin.delegate = self
        reEnteredMPin.tag = 3
    }
    
    func viewConfiguration() {
        
        signUpView.isHidden = true
        
        logInTextViews.forEach  { (currentView) in
            
            currentView.layer.cornerRadius = CornerRadius.textField.rawValue
        }
        
        signInIndicatorView.layer.cornerRadius = CornerRadius.indicator.rawValue
        
        mPinTextField.isSecureTextEntry = true
        reEnteredMPin.isSecureTextEntry = true
    }

    
    @IBAction func showPassword(_ sender: UIButton) {
        
        if let passwordButton = sender as? ToggleButton {
            
            passwordButton.toggle()
            
            if sender.tag == 1 {
                
                mPinTextField.isSecureTextEntry = !mPinTextField.isSecureTextEntry
            } else {
                
                reEnteredMPin.isSecureTextEntry = !reEnteredMPin.isSecureTextEntry
            }
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        
        navigationController?.setNavigationBarHidden(true, animated: false)
        mobileNumberTextField.text = ""
        mPinTextField.text = ""
        mobileNumberInSignUpTextField.text = ""
        mPinInSignUpTextField.text = ""
        reEnteredMPin.text = ""
    }
    
    override func viewDidLayoutSubviews() {
        
        if let view = view as? CustomBackgroundView {
            
            view.loginLayer.frame = self.view.bounds
        }
        
        if (!heightNotSet) {
            if (UIDevice.current.orientation.isLandscape ) {
                
                subViewHeight = scrollView.frame.width
                print("Device is in landscape mode")
                heightNotSet = true
            } else {
                
                subViewHeight = scrollView.frame.height
                print("Device is in portrait mode")
                heightNotSet = true
            }
        }
        
        let height = NSLayoutConstraint(item: subView ?? "", attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: subViewHeight)
        
        subView.addConstraint(height)
    }
    
    
    @IBAction func signInClicked(_ sender: Any) {
        
        let duration: Double = 0.6
        
        UIView.animate(withDuration: duration) {
            
            self.signInIndicatorView.center.x -= self.subView.center.x
        }
        
        signInButton.titleLabel?.font = UIFont(name: "OpenSans-Bold", size: 20)
        signUpButton.titleLabel?.font = UIFont(name: "OpenSans-SemiBold", size: 20)
        signUpView.isHidden = true
        signInView.isHidden = false
        
        mobileNumberTextField.text = ""
        mPinTextField.text = ""
    }
    
    @IBAction func signUpClicked(_ sender: Any) {
        
        let duration: Double = 0.6
        
        UIView.animate(withDuration: duration) {
            
            self.signInIndicatorView.center.x += self.subView.center.x
        }
        
        signUpButton.titleLabel?.font = UIFont(name: "OpenSans-Bold", size: 20)
        signInButton.titleLabel?.font = UIFont(name: "OpenSans-SemiBold", size: 20)
        signInView.isHidden = true
        signUpView.isHidden = false
        
        mobileNumberInSignUpTextField.text = ""
        mPinInSignUpTextField.text = ""
        reEnteredMPin.text = ""
    }
    

    @IBAction func signInSuccessful(_ sender: Any) {
        
        guard let mobile = mobileNumberTextField.text, !mobile.isEmpty, let mPin = mPinTextField.text, !mPin.isEmpty, let mPinIntVal = Int(mPin)
        else {
            
            UIAlertController().alertMessageDisplay(title: alertStrings.missingDetails.rawValue, message: alertStrings.requiredDetails.rawValue, buttonTitle: "OK", parentView: self)
            
            return
        }
        
        let valid = loginModel.validate(mobileNumber: mobile, mPin: mPinIntVal)
        
        if valid == false {
            
            UIAlertController().alertMessageDisplay(title: alertStrings.wrongDetails.rawValue , message: "", buttonTitle: "OK", parentView: self)
            
            return
        }
            
        loginModel.saveLoginDetails()
                
        let siteTableView = self.storyboard?.instantiateViewController(identifier: "TableViewController") as! SiteTableViewController
                
        siteTableView.currentUserMobileNumber = mobile
                
        self.navigationController?.pushViewController(siteTableView, animated: true)
          
    }
    
    @IBAction func signUpSuccessful(_ sender: Any) {
        
        guard let mobile = mobileNumberInSignUpTextField.text, !mobile.isEmpty, let mPin = mPinInSignUpTextField.text, !mPin.isEmpty, let reMpin = reEnteredMPin.text, !reMpin.isEmpty, let mPinIntVal = Int(mPin)
        else {
            
            UIAlertController().alertMessageDisplay(title: alertStrings.missingDetails.rawValue, message: alertStrings.requiredDetails.rawValue, buttonTitle: "OK", parentView: self)
            
            return
        }
            
        let valid = loginModel.validate(mobileNumber: mobile, mPin: mPinIntVal)
            
        if valid == true {
            
            UIAlertController().alertMessageDisplay(title: alertStrings.userExist.rawValue, message: "", buttonTitle: "OK", parentView: self)
            
            return
        }
        
        if mPin != reMpin {
            
            UIAlertController().alertMessageDisplay(title: alertStrings.mPinMismatch.rawValue, message: alertStrings.checkMpin.rawValue, buttonTitle: "OK", parentView: self)
            
            return
        }
                    
        loginModel.addUser(mobileNumber: mobile, mPin: mPinIntVal)
                    
        signUpView.isHidden = true
        signInView.isHidden = false
        
        UIAlertController().alertMessageDisplay(title: alertStrings.success.rawValue, message: alertStrings.login.rawValue , buttonTitle: "OK", parentView: self)
    }
}

extension SignInController: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField.tag == 1 {

            return TextValidatorUtility().isValidMobileNumber(number: string)
        
        } else if textField.tag == 2  {
            
            return TextValidatorUtility().isValidMPin(pin: string)
        
        } else {
            
            return true
        }
    }
}
