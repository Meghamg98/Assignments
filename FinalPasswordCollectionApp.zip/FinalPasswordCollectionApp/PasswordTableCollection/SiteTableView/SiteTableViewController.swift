//
//  SiteTableViewController.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 17/05/21.
//

import UIKit

class SiteTableViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var sitesView: UIView!
    
    @IBOutlet weak var folderListNumberView: UIView!
    @IBOutlet weak var folderNumberLabel: UILabel!
    
    @IBOutlet weak var selectFolderButton: UIButton!
    @IBOutlet var differentFolderButtons: [UIButton]!
    @IBOutlet weak var selectedfolderLabel: UILabel!
    @IBOutlet weak var folderStackView: UIStackView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var indexPosition: Int  = -1
    var siteViewModel = SiteViewModel()
    var currentUserMobileNumber = ""
    
    var folderArrayCount: Int {
        
        if let folder = selectedfolderLabel.text, !folder.isEmpty {
            let siteArray = siteViewModel.requiredData(folder: folder)
            return siteArray.count
        }
        return 0
    }
    
    var currentArrayCount: Int {
        
        if siteViewModel.currentStatus == .searchSelected {
            
            return siteViewModel.filteredArrayCount
            
        } else if siteViewModel.currentStatus == .searchNotSelected {
            
            return folderArrayCount
        }
        return 0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = 110
        
        differentFolderButtons.forEach  { (selectedButton) in

            selectedButton.isHidden = true
        }
        
        siteViewModel.loadSiteDetails(mobileNumber: self.currentUserMobileNumber)
        searchBar.delegate = self
        
        self.viewConfiguration()
    }
  
    func viewConfiguration() {
        
        navigationController?.setNavigationBarHidden(false, animated: false)
        
        folderListNumberView.layer.borderWidth = BorderWidth.siteCountView.rawValue
        folderListNumberView.backgroundColor =  UIColor.dropDownViewColor()
        folderListNumberView.layer.borderColor = UIColor.white.cgColor
        folderListNumberView.layer.cornerRadius = CornerRadius.siteCountView.rawValue
        
        //searchBar.isHidden = true
        
        siteViewModel.filteredArray = siteViewModel.requiredData(folder: selectedfolderLabel.text ?? "")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.tableView.reloadData()
        
        siteViewModel.loadSiteDetails(mobileNumber: self.currentUserMobileNumber)
        folderNumberLabel.text = String(folderArrayCount)
        
    }

    @IBAction func logOutButtonClicked(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func selectFolderButtonClicked(_ sender: Any) {
   
        differentFolderButtons.forEach  { (selectedButton) in
            UIView.animate(withDuration: 0.7) {
                
                selectedButton.isHidden = !selectedButton.isHidden
                selectedButton.layoutIfNeeded()
            }
        }
    }

    @IBAction func copyPasswordButtonClicked(_ sender: Any) {
        
        print("Copy password button clicked")
        
        if let folder = selectedfolderLabel.text {
                
            let site = siteViewModel.fetchRequiredSiteAtIndex(index: (sender as AnyObject).tag, folder: folder)
            UIPasteboard.general.string = site?.password
        }
    }
    
    @IBAction func folderSelected(_ sender: Any) {
        
        if let buttonLabel = (sender as AnyObject).titleLabel?.text {
            selectedfolderLabel.text = buttonLabel
            folderNumberLabel.text = String(folderArrayCount)
            print("You have selected \(buttonLabel) folder")
            
        }
        
        self.tableView.reloadData()
        
        differentFolderButtons.forEach  { (selectedButton) in
            UIView.animate(withDuration: 0.7) {
                
                selectedButton.isHidden = true
                selectedButton.layoutIfNeeded()
            }
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        print("Touched outside")
        differentFolderButtons.forEach  { (selectedButton) in
            UIView.animate(withDuration: 0.7) {
                
                selectedButton.isHidden = true
                selectedButton.layoutIfNeeded()
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let destination = segue.destination as? SiteDetailsController {
            
            destination.delegate = self
            
            if (segue.identifier == "AddSiteDetails") {
                
                destination.currentStatus = .addSiteDetails
                
            } else if (segue.identifier == "EditSiteDetails") {
                
                destination.currentStatus = .editSiteDetails
                
                if siteViewModel.currentStatus == .searchSelected {
                    
                    let site = siteViewModel.filteredArray[indexPosition]
                    destination.currentSite = site
                    
                } else if siteViewModel.currentStatus == .searchNotSelected {
                    
                    if let temp = selectedfolderLabel.text {
                        
                        let site = siteViewModel.fetchRequiredSiteAtIndex(index: indexPosition, folder: temp)
                        destination.currentSite = site
                    }
                }
            }
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        siteViewModel.currentStatus = .searchNotSelected
        let duration: Double = 1.0
        UIView.animate(withDuration: duration) {

            self.searchBar.center.y -= self.sitesView.center.y
        }
        searchBar.text = ""
        searchBar.resignFirstResponder()
        
        siteViewModel.requiredData(folder: selectedfolderLabel.text ?? "")
        self.tableView.reloadData()
    }
    
    @IBAction func searchButtonClicked(_ sender: Any) {
        
        siteViewModel.currentStatus = .searchSelected
        let duration: Double = 1.0
        
        UIView.animate(withDuration: duration) {
                
            self.searchBar.center.y += self.sitesView.center.y
        }
        
    }
}
       
extension SiteTableViewController: AddSiteProtocol {
    
    func addNewSite(url: String, siteName: String, folder: String, userName: String, password: String, notes: String?) {
        
        siteViewModel.addSite(url: url, siteName: siteName, folder: folder, userName: userName, password: password, notes: notes)
        
        self.tableView.reloadData()
        siteViewModel.saveSiteDetails(mobileNumber: self.currentUserMobileNumber)
        
        
    }
    
    func editExistingSite(url: String, siteName: String, folder: String, userName: String, password: String, notes: String?, previousFolder: String) {
        
        siteViewModel.editSiteAtIndex(index: indexPosition, url: url, siteName: siteName, folder: folder, userName: userName, password: password, notes: notes, previousFolder: previousFolder, selectedFolder: selectedfolderLabel.text ?? "")
        
        self.tableView.reloadData()
        siteViewModel.saveSiteDetails(mobileNumber: self.currentUserMobileNumber)
        

    }
}

extension SiteTableViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
        
            siteViewModel.deleteSite(index: indexPath.row, folder: selectedfolderLabel.text ?? "")

            siteViewModel.requiredData(folder: selectedfolderLabel.text ?? "")
            siteViewModel.saveSiteDetails(mobileNumber: currentUserMobileNumber)
            
        }
        tableView.reloadData()
        
        folderNumberLabel.text = String(folderArrayCount)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return currentArrayCount
    }
    
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        
        indexPosition = indexPath.row
        return indexPath
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as? MyCell {
            
            cell.layer.cornerRadius = 10
            
            var site: SiteDetails?
            
            if siteViewModel.currentStatus == .searchSelected {
                
                site = siteViewModel.filteredArray[indexPath.row]
                
            } else if siteViewModel.currentStatus == .searchNotSelected {
                
                if let temp = selectedfolderLabel.text, !temp.isEmpty {

                    site = siteViewModel.fetchRequiredSiteAtIndex(index: indexPath.row, folder: temp)
                }
            }
            
            cell.siteNameLabel.text = site?.siteName
            cell.urlLabel.text = site?.url
            cell.copyPasswordButton.tag = indexPath.row
            
            if let currentSite = site?.siteName.lowercased() {
                
                cell.siteicon.image = UIImage.imageFor(name: currentSite)
            }

            return cell
        }
        return MyCell()
    }
    
}

extension SiteTableViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        siteViewModel.filteredArray = []
        
        let siteArray = siteViewModel.requiredData(folder: selectedfolderLabel.text ?? "")
        
        if(searchText == "") {
            
            siteViewModel.filteredArray = siteArray
            
        } else {
            
            siteViewModel.searchSite(searchText: searchText, currentFolder: selectedfolderLabel.text ?? "")
        }
        self.tableView.reloadData()
    }
}

