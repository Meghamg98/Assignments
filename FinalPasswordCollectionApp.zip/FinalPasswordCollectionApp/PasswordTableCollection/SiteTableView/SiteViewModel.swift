//
//  SiteViewModel.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 30/04/21.
//

import Foundation

class SiteViewModel {
    
    var siteDetailsArray = [SiteDetails]()
    var requiredFolderDetails = [SiteDetails?]()
    var filteredArray = [SiteDetails?]()

    enum Status: String {
        
        case searchSelected
        case searchNotSelected
    }
    
    var currentStatus: Status = .searchNotSelected
    
    var filteredArrayCount: Int {
        
        return filteredArray.count
    }
    
    func addSite(url: String, siteName: String, folder: String, userName: String, password: String, notes: String?) {

        let site = SiteDetails(url: url, siteName: siteName, folder: folder, userName: userName, password: password, notes: notes)
        siteDetailsArray.append(site)
        print("Site added successfully to \(folder)")
    }
    
    func fetchRequiredSiteAtIndex(index: Int, folder: String) -> SiteDetails? {

        var site: SiteDetails?
        requiredFolderDetails = self.requiredData(folder: folder)
        
        if index >= 0 && index < requiredFolderDetails.count {
          
            site = requiredFolderDetails[index]
            return site
        }
        return nil
    }
    
    func requiredData(folder: String) -> [SiteDetails?] {
        
        if folder == "All" {
            
            return siteDetailsArray
            
        } else {
            
            var requiredSiteArray = [SiteDetails]()
            
            requiredSiteArray = siteDetailsArray.filter() {
                $0.folder == folder
            }
            
            return requiredSiteArray
        }
    }
    
    func editSiteAtIndex(index: Int, url: String, siteName: String, folder: String, userName: String, password: String, notes: String?, previousFolder: String, selectedFolder: String) {

        var selectedSite: SiteDetails?
        
        if currentStatus == .searchSelected {
            
            selectedSite = self.filteredArray[index]

        } else if currentStatus == .searchNotSelected {
            
            if selectedFolder == "All" {
                   
                selectedSite = siteDetailsArray[index]
                
            } else {
                
                selectedSite = self.fetchRequiredSiteAtIndex(index: index, folder: previousFolder)
            }
        }
        
        if let site = selectedSite {
        
            site.url = url
            site.siteName = siteName
            site.folder = folder
            site.userName = userName
            site.password = password
            site.notes = notes
        
        }
    }
    
    func deleteSite(index: Int, folder: String) {
        
        var count = -1
        if folder == "All" {
            
            siteDetailsArray.remove(at: index)
            
        } else {
            
            for i in 0..<siteDetailsArray.count {
                if siteDetailsArray[i].folder == folder {
                    
                    count += 1
                    if count == index {
                        siteDetailsArray.remove(at: i)
                        break
                    }
                }
            }
        }
    }
    
    func searchSite(searchText: String, currentFolder: String) {
        
        let siteArray = requiredData(folder: currentFolder)
        
        for site in siteArray {
            
            let siteName = site?.siteName
            let siteUrl = site?.url
            if let name = siteName, let url = siteUrl {
                
                if (name.lowercased().contains(searchText.lowercased()))||(url.lowercased().contains(searchText.lowercased())) {
                    filteredArray.append(site)
                }
            }
        }
    }
    
    func saveSiteDetails(mobileNumber: String) {
        
        do{
            let siteData = try
                NSKeyedArchiver.archivedData(withRootObject: self.siteDetailsArray, requiringSecureCoding: false)
            try siteData.write(to: URL.createSiteFilePathForUser(mobileNumber: mobileNumber))
        } catch {
            print("Path not found")
        }
    }
    
    func loadSiteDetails(mobileNumber: String) {
        
        do{
            let siteData = try
                Data(contentsOf: URL.createSiteFilePathForUser(mobileNumber: mobileNumber))
            if let site = try
                NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(siteData) as? [SiteDetails] {
                self.siteDetailsArray = site
            }
        } catch {
            print("File not found")
        }
    }
}
