//
//  MyCell.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 29/04/21.
//

import UIKit

class MyCell: UITableViewCell {

    @IBOutlet weak var urlLabel: UILabel!
    
    @IBOutlet weak var siteicon: UIImageView!
    @IBOutlet weak var siteNameLabel: UILabel!
    @IBOutlet weak var copyPasswordButton: UIButton!
    
    override func layoutSubviews() {
        super.layoutSubviews()

        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0))
        contentView.layer.cornerRadius = CornerRadius.siteCell.rawValue
        
    }
}
