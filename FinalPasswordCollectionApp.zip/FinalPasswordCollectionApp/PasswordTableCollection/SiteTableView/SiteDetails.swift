//
//  SiteDetails.swift
//  PasswordTableCollection
//
//  Created by Megha M Gamskar on 30/04/21.
//

import Foundation

class SiteDetails: NSObject, NSCoding {
    
    private static var lastId: Int = 0
    
    var url: String
    var siteName: String
    var folder: String
    var userName: String
    var password: String
    var notes: String?
    var id: Int
    
    init(url: String, siteName: String, folder: String, userName: String, password: String, notes: String?) {
        
        self.url = url
        self.siteName = siteName
        self.folder = folder
        self.userName = userName
        self.password = password
        self.notes = notes
        self.id = SiteDetails.lastId + 1
        SiteDetails.lastId = SiteDetails.lastId + 1
    }
    
    func encode(with coder: NSCoder) {
        
        coder.encode(self.url, forKey: SiteDetailsKey.url.rawValue)
        coder.encode(self.siteName, forKey: SiteDetailsKey.siteName.rawValue)
        coder.encode(self.folder, forKey: SiteDetailsKey.folder.rawValue)
        coder.encode(self.userName, forKey: SiteDetailsKey.userName.rawValue)
        coder.encode(self.password, forKey: SiteDetailsKey.password.rawValue)
        coder.encode(self.notes, forKey: SiteDetailsKey.notes.rawValue)
        coder.encode(self.id, forKey: SiteDetailsKey.id.rawValue)
        
    }
    
    required init? (coder: NSCoder) {
        
        guard let url = coder.decodeObject(forKey: SiteDetailsKey.url.rawValue) as? String,
              let siteName = coder.decodeObject(forKey: SiteDetailsKey.siteName.rawValue) as? String,
              let folder = coder.decodeObject(forKey: SiteDetailsKey.folder.rawValue) as? String,
              let userName = coder.decodeObject(forKey: SiteDetailsKey.userName.rawValue) as? String,
              let password = coder.decodeObject(forKey: SiteDetailsKey.password.rawValue) as? String,
              let id = coder.decodeInteger(forKey: SiteDetailsKey.id.rawValue) as? Int
        else {
            return nil
        }
        
        self.url = url
        self.siteName = siteName
        self.folder = folder
        self.userName = userName
        self.password = password
        self.notes = coder.decodeObject(forKey: SiteDetailsKey.notes.rawValue) as? String
        self.id = id
    }
   
}
