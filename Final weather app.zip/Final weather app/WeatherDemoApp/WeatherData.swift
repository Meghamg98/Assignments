//
//  WeatherData.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 11/06/21.
//

import Foundation

class WeatherData: NSObject, NSCoding {
    
    var temperature: Double
    var minTemp: Double
    var maxTemp: Double
    var precipitation: Double
    var humidity: Double
    var wind: Double
    var visibility: Double
    var locationName: String
    var weatherDescription: String
    var weatherName: String
    var cityId: Int
    var time: String
    
    init(temperature: Double, minTemp: Double, maxTemp: Double, precipitation: Double, humidity: Double, wind: Double, visibility: Double, locationName: String, weatherDescription: String, weatherName: String, cityId: Int, time: String) {
        
        self.temperature = temperature
        self.minTemp = minTemp
        self.maxTemp = maxTemp
        self.precipitation = precipitation
        self.humidity = humidity
        self.wind = wind
        self.visibility = visibility
        self.locationName = locationName
        self.weatherDescription = weatherDescription
        self.weatherName = weatherName
        self.cityId = cityId
        self.time = time
    }
    
    func encode(with coder: NSCoder) {

        coder.encode(self.temperature, forKey: WeatherDataKeys.temperature.rawValue)
        coder.encode(self.minTemp, forKey: WeatherDataKeys.minTemp.rawValue)
        coder.encode(self.maxTemp, forKey: WeatherDataKeys.maxTemp.rawValue)
        coder.encode(self.precipitation, forKey: WeatherDataKeys.precipitation.rawValue)
        coder.encode(self.humidity, forKey: WeatherDataKeys.humidity.rawValue)
        coder.encode(self.wind, forKey: WeatherDataKeys.wind.rawValue)
        coder.encode(self.visibility, forKey: WeatherDataKeys.visibility.rawValue)
        coder.encode(self.locationName, forKey: WeatherDataKeys.locationName.rawValue)
        coder.encode(self.weatherDescription, forKey: WeatherDataKeys.weatherDescription.rawValue)
        coder.encode(self.weatherName, forKey: WeatherDataKeys.weatherName.rawValue)
        coder.encode(self.cityId, forKey: WeatherDataKeys.cityId.rawValue)
        coder.encode(self.time, forKey: WeatherDataKeys.time.rawValue)
            
    }

    required init?(coder: NSCoder) {

        guard
            let location = coder.decodeObject(forKey: WeatherDataKeys.locationName.rawValue) as? String,
              let description = coder.decodeObject(forKey: WeatherDataKeys.weatherDescription.rawValue) as? String,
              let weatherCondition = coder.decodeObject(forKey: WeatherDataKeys.weatherName.rawValue) as? String,
              let time = coder.decodeObject(forKey: WeatherDataKeys.time.rawValue) as? String
        else {
            return nil
        }
        
        self.temperature = coder.decodeDouble(forKey: WeatherDataKeys.temperature.rawValue)
        self.minTemp = coder.decodeDouble(forKey: WeatherDataKeys.minTemp.rawValue)
        self.maxTemp = coder.decodeDouble(forKey: WeatherDataKeys.maxTemp.rawValue)
        self.precipitation = coder.decodeDouble(forKey: WeatherDataKeys.precipitation.rawValue)
        self.humidity = coder.decodeDouble(forKey: WeatherDataKeys.humidity.rawValue)
        self.wind = coder.decodeDouble(forKey: WeatherDataKeys.wind.rawValue)
        self.visibility = coder.decodeDouble(forKey: WeatherDataKeys.visibility.rawValue)
        self.locationName = location
        self.weatherDescription = description
        self.weatherName = weatherCondition
        self.cityId = coder.decodeInteger(forKey: WeatherDataKeys.cityId.rawValue)
        self.time = time
    }
}
