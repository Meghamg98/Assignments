//
//  WeatherViewModel.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 11/06/21.
//

import Foundation

protocol WeatherDataProtocol: AnyObject {
    
    func weatherDataReceived()
}

class WeatherViewModel: WeatherDataParsed {
    
    var networkManager = NetworkManager()
    var currentWeatherData = emptyWeatherData
    weak var delegate: WeatherDataProtocol?
    var favouriteModel = FavouriteViewModel()
    
    func fetchWeatherDataFromServer(lattitude: Double, longitude: Double) {
        
        networkManager.delegate = self
        networkManager.fetchWeatherDataBasedOn(lattitude: lattitude, longitude: longitude)
    }
    
    func receiveWeatherList(list: WeatherData) {
        
        self.currentWeatherData = list
        print(currentWeatherData.locationName)
        self.delegate?.weatherDataReceived()
        
        if searchEnum == .searchSelected {

            favouriteModel.addToRecentSearchList(weatherDataObject: currentWeatherData)
            searchEnum = .searchNotSelected
        }
    }
    
    func searchWeatherDataForCityNamed(name: String) {
        
        networkManager.delegate = self
        networkManager.fetchWeatherDataBasedOnName(cityname: name)
    }
}
