//
//  WeatherCollectionViewCell.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 10/06/21.
//

import UIKit

class WeatherCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var condition: UILabel!
    @IBOutlet weak var value: RobotoMediumWhiteLabels!
}
