//
//  HomeScreenViewController.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 09/06/21.
//

import UIKit
import MapKit
import CoreLocation

class HomeScreenViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var subView: UIView!
    @IBOutlet weak var weatherView: UICollectionView!
    @IBOutlet weak var separaterView: UIView!
    @IBOutlet weak var burgerMenuView: UIView!    
    @IBOutlet weak var dateAndTime: UILabel!
    @IBOutlet weak var locationName: RobotoMediumWhiteLabels!
    @IBOutlet weak var weatherConditionImage: UIImageView!
    @IBOutlet weak var temperatureValue: UILabel!
    @IBOutlet weak var weatherConditionDescription: UILabel!
    @IBOutlet weak var favouriteButton: FavoriteButtonToggle!
    @IBOutlet weak var tempSegmentControl: CustomSegmentControl!
    
    var subViewHeight: CGFloat = 0.0
    var isHeightSet: Bool = false
    
    var weatherViewModel = WeatherViewModel()
    var currentWeather: WeatherData?
    
    var favouriteViewModel = FavouriteViewModel()
    var collectionViewArray = [String]()
    
    var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        
        self.accessCurrentLocation()
        
        self.burgerMenuView.isHidden = true
        
        let tap = UITapGestureRecognizer(target: self, action:  #selector(handle(tapGestureRecognizer:)))
        scrollView.isUserInteractionEnabled = true
        scrollView.addGestureRecognizer(tap)
    
        weatherViewModel.delegate = self
        
        if let favouriteTableView = self.storyboard?.instantiateViewController(identifier: "WeatherViewController") as? WeatherViewController {
            
            favouriteTableView.weatherTableDelegate = self
        }
        
        favouriteViewModel.loadFavouriteDetails()
        favouriteViewModel.loadRecentSearchDetails()
        favouriteViewModel.loadTempUnit()
        
        if(favouriteViewModel.currentTempUnit == "fahrenheit"){
            
            tempSegmentControl.selectedSegmentIndex = 1
        }
    }
    
    func accessCurrentLocation() {
        
        if (CLLocationManager.locationServicesEnabled()) {

            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestAlwaysAuthorization()
            locationManager.startUpdatingLocation()
        } else {
            print("Location not found")
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {

        let location = (locations.last ?? CLLocation())

        let lat = location.coordinate.latitude
        let long = location.coordinate.longitude
        print("Lattitude:\(lat)")
        print("Longitude:\(long)")
        
        weatherViewModel.fetchWeatherDataFromServer(lattitude: lat, longitude: long)
    }
    
    @objc func handle(tapGestureRecognizer: UITapGestureRecognizer) {
        
        UIView.animate(withDuration: 0.8) {
            
            self.burgerMenuView.center.x -= 270
        }
    }
    
    override func viewDidLayoutSubviews() {
        
        self.burgerMenuView.isHidden = true
        
        if let view = view as? CustomBackgroundImage {
            
            view.backgroundLayer.frame = self.view.bounds
        }
        
        if (!isHeightSet) {
            
            if (UIDevice.current.orientation.isLandscape ) {
                
                subViewHeight = scrollView.frame.width
                print("Device is in landscape mode")
                isHeightSet = true
                
            } else {
                
                subViewHeight = scrollView.frame.height
                print("Device is in portrait mode")
                isHeightSet = true
            }
        }
                
        let height = NSLayoutConstraint(item: subView ?? "", attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: subViewHeight)
        
        subView.addConstraint(height)
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    @IBAction func addToFavoriteButtonTapped(_ sender: Any) {
        
        print(favouriteViewModel.currentTempUnit)
        
        if let favourite = sender as? FavoriteButtonToggle {
        
            favourite.toggle()
        }
        
        let isPresentInFav = favouriteViewModel.validate(cityId: currentWeather?.cityId ?? 0)
        if isPresentInFav == true {
            
            favouriteViewModel.favouriteArray.remove(at: (sender as AnyObject).tag)
            print("Removed")
        } else {
            
            if let weather = self.currentWeather {
                
                favouriteViewModel.addToFavouriteList(weatherDataObject: weather)
            }
            print("Added")
        }
        
        print("Add to favorite tapped")
       
    }
    
    @IBAction func burgerMenuPressed(_ sender: Any) {
        
        UIView.animate(withDuration: 0.8) {
            
            self.burgerMenuView.isHidden = false
            self.burgerMenuView.center.x += 270
        }
    }
    
    @IBAction func burgerMenuButtonPressed(_ sender: Any) {
        
        UIView.animate(withDuration: 0.8) {
            
            self.burgerMenuView.center.x -= 270
        }
        //self.burgerMenuView.isHidden = true
    }
    
    
    @IBAction func selectTempMeasureTapped(_ sender: CustomSegmentControl) {
        
        var min = 0.0
        var max = 0.0
        
        if sender.selectedSegmentIndex == 0 {
            
            favouriteViewModel.currentTempUnit = "celcius"
            
            if let temp = temperatureValue.text, let tempVal = Int(temp) {
                
                let celciusTemperature = (tempVal - 32) * 5 / 9
                temperatureValue.text = String(celciusTemperature)
            }
            
            if let currentWeather = currentWeather {
                
                max = (currentWeather.maxTemp - 32) * 5 / 9
                min = (currentWeather.maxTemp - 32) * 5 / 9
                currentWeather.maxTemp = max
                currentWeather.minTemp = min
            }
              
        } else if sender.selectedSegmentIndex == 1 {
            
            favouriteViewModel.currentTempUnit = "fahrenheit"
            
            if let temp = temperatureValue.text, let tempVal = Int(temp) {
                
                let fahrenheitTemperature = tempVal * 9 / 5 + 32
                temperatureValue.text = String(fahrenheitTemperature)
            }
            if let currentWeather = currentWeather {
                
                max = currentWeather.maxTemp * 9 / 5 + 32
                min = currentWeather.minTemp * 9 / 5 + 32
                currentWeather.maxTemp = max
                currentWeather.minTemp = min
            }
        }
        
        collectionViewArray.removeAll()
        collectionViewArray.append("\(Int(min))°- \(Int(max))°")
        self.appendToCollectionArray()
        
        print(collectionViewArray[0])
        self.weatherView.reloadData()
        
        favouriteViewModel.saveTempUnit()
    }
    
    @IBAction func burgerMenuFavouriteTapped(_ sender: Any) {
        
        let isFavourite = favouriteViewModel.validate(cityId: currentWeather?.cityId ?? 0)
        if (isFavourite) {
            
            favouriteButton.toggle()
        }
        
        if let favouriteTableView = self.storyboard?.instantiateViewController(identifier: "WeatherViewController") as? WeatherViewController {
            
            favouriteTableView.weatherTableDelegate = self
            favouriteTableView.currentStatus = .favourite
            favouriteTableView.favouriteModel = self.favouriteViewModel
            self.navigationController?.pushViewController(favouriteTableView, animated: true)
        }
    }
    
    @IBAction func burgerMenuRecentTapped(_ sender: Any) {
        
        let isFavourite = favouriteViewModel.validate(cityId: currentWeather?.cityId ?? 0)
        if (isFavourite) {

            favouriteButton.toggle()
        }
        
        if let favouriteTableView = self.storyboard?.instantiateViewController(identifier: "WeatherViewController") as? WeatherViewController {
            
            favouriteTableView.weatherTableDelegate = self
            favouriteTableView.currentStatus = .recentSearch
            favouriteTableView.favouriteModel = self.favouriteViewModel
            self.navigationController?.pushViewController(favouriteTableView, animated: true)
        }
    }
    
    @IBAction func searchButtonTapped(_ sender: Any) {
        
        let isFavourite = favouriteViewModel.validate(cityId: currentWeather?.cityId ?? 0)
        if (isFavourite) {
            
            favouriteButton.toggle()
        }
        
        if let searchController = self.storyboard?.instantiateViewController(identifier: "SearchViewController") as? SearchViewController {
            
            searchController.searchToHomeDelegate = self
            //searchController.weatherViewModel = self.weatherViewModel
            weatherViewModel.favouriteModel = self.favouriteViewModel
            searchController.favouriteViewModel = self.favouriteViewModel
            self.navigationController?.pushViewController(searchController, animated: true)
        }
    }
}

extension HomeScreenViewController: WeatherDataProtocol {
        
    func weatherDataReceived() {
       
        DispatchQueue.main.async {
           
            self.weatherView.reloadData()
            self.currentWeather = self.weatherViewModel.currentWeatherData
            
            if let weather = self.currentWeather {
                
                print(weather.locationName)
                
                if self.favouriteViewModel.currentTempUnit == "celcius" {
                    
                    self.temperatureValue.text = String("\(Int(weather.temperature))")
                    self.collectionViewArray.removeAll()
                    self.collectionViewArray.append("\(Int(weather.minTemp))°- \(Int(weather.maxTemp))°")
                    
                } else {
                    
                    let toFah = weather.temperature * 9 / 5 + 32
                    self.temperatureValue.text = String("\(Int(toFah))")
                    self.collectionViewArray.removeAll()
                    let min = weather.minTemp * 9 / 5 + 32
                    let max = weather.maxTemp * 9 / 5 + 32
                    self.collectionViewArray.append("\(Int(min))°- \(Int(max))°")
                    self.currentWeather?.maxTemp = max
                    self.currentWeather?.minTemp = min
                }
                
                //self.temperatureValue.text = String("\(Int(weather.temperature))")
                self.locationName.text = weather.locationName
                
                self.weatherConditionImage.image = UIImage.imageFor(name: weather.weatherName)
                self.weatherConditionDescription.text = weather.weatherDescription.capitalized
                //self.collectionViewArray.removeAll()
                //self.collectionViewArray.append("\(Int(weather.minTemp))°- \(Int(weather.maxTemp))°")
                self.appendToCollectionArray()
                
                let isFavourite = self.favouriteViewModel.validate(cityId: weather.cityId)
                
                if(isFavourite) {
                    self.favouriteButton.toggle()
                }
            }
        }
    }
    
    func appendToCollectionArray() {
        
        if let weather = self.currentWeather {
        
            collectionViewArray.append("\(weather.precipitation)")
            collectionViewArray.append("\(weather.humidity)")
            collectionViewArray.append("\(weather.wind)")
            collectionViewArray.append("\(weather.visibility)")
        }
    }
}

extension HomeScreenViewController: WeatherTableProtocol, SearchForCity {
    
    func displayWeatherFor(cityName: String, sessionExpired: Bool) {
        
        if(sessionExpired) {
            print("New data")
            weatherViewModel.searchWeatherDataForCityNamed(name: cityName)
        } else {
            print("Data from recent")
            let weatherData = favouriteViewModel.fetchFromRecent(cityName: cityName)
            weatherViewModel.currentWeatherData = weatherData
            self.weatherDataReceived()
        }
    }
    
    func searchCityWith(name: String) {
        
        weatherViewModel.searchWeatherDataForCityNamed(name: name)
        
    }
}

extension HomeScreenViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "WeatherCell", for: indexPath) as? WeatherCollectionViewCell {
            
            cell.imageView.image = imageArray[indexPath.row]
            cell.condition.text = conditionArray[indexPath.row]
            
            if indexPath.row < collectionViewArray.count, indexPath.row >= 0 {
                
                cell.value.text = collectionViewArray[indexPath.row]
            } else {
                
                print("Cell error")
            }
            
            return cell
        }
        
        return WeatherCollectionViewCell()
    }
}


