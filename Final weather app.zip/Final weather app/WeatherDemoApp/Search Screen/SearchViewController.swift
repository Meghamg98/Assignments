//
//  SerachViewController.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 11/06/21.
//

import UIKit

protocol SearchForCity: AnyObject {
    
    func searchCityWith(name: String)
}

class SearchViewController: UIViewController  {
    
    @IBOutlet weak var searchTableView: UITableView!
    @IBOutlet weak var serachTextField: UITextField!
    
    //var weatherViewModel = WeatherViewModel()
    var favouriteViewModel = FavouriteViewModel()
    var recentSearch = emptyWeatherData
    
    weak var searchToHomeDelegate: SearchForCity?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        searchTableView.delegate = self
        searchTableView.dataSource = self
        
        serachTextField.delegate = self
        
        self.searchTableView.rowHeight = 50
        self.navigationController?.isNavigationBarHidden = true
        
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        
        //searchEnumValue = .searchNotSelected
        //searchEnum = .searchNotSelected
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension SearchViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath) as? SearchTableViewCell {
            
            cell.cityName.text = "Udupi"
           return cell
        }
        return SearchTableViewCell()
    }
}

extension SearchViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        searchEnum = .searchSelected
        
        print("Text returned")
        if let city = textField.text, !city.isEmpty {
            
            print(city)
            self.searchToHomeDelegate?.searchCityWith(name: city.lowercased())
            
        }
        favouriteViewModel.saveRecentSearchDetails()
        //searchEnum = .searchNotSelected
        self.navigationController?.popViewController(animated: true)
        return false
    }
}
