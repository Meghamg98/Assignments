//
//  SearchTableViewCell.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 11/06/21.
//

import UIKit

class SearchTableViewCell: UITableViewCell {

    @IBOutlet weak var cityName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    

}
