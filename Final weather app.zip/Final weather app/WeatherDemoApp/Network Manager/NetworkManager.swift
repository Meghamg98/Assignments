//
//  NetworkManager.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 11/06/21.
//

import Foundation
import UIKit

protocol WeatherDataParsed: AnyObject {
    
    func receiveWeatherList(list: WeatherData)
}

class NetworkManager {
    
    weak var delegate: WeatherDataParsed?

    func fetchWeatherDataBasedOnName(cityname: String) {
        //create URL
        guard let weatherDataURL = URL(string: "https://api.openweathermap.org/data/2.5/weather?q=\(cityname)&appid=5582662096adca2cf6f411f8e7257745&units=metric")
        else {
            return
        }
        
        self.fetchWeatherData(urlName: weatherDataURL)
    }
    
    func fetchWeatherDataBasedOn(lattitude: Double, longitude: Double) {
        
        //create URL
        guard let urlBasedOnLatLong = URL(string: "https://api.openweathermap.org/data/2.5/weather?lat=\(lattitude)&lon=\(longitude)&appid=5582662096adca2cf6f411f8e7257745&units=metric")
        else {
            return
        }
        
        self.fetchWeatherData(urlName: urlBasedOnLatLong)
    }
    
    func fetchWeatherData(urlName: URL) {
        
        //create a session
        let session = URLSession.shared
        
        //create a task
        let task = session.dataTask(with: urlName) {
            
            [weak self]
            (data, response, error)
            in
            
            if (error != nil) {
                return
            }
            
            guard let response = response as? HTTPURLResponse, response.statusCode == 200
            else {
                return
            }
            
            guard let data = data
            else {
                return
            }
            
            do {
                
                let weatherDataObject = try JSONSerialization.jsonObject(with: data, options: [])
                
                if let weatherList = self?.parseWeatherData(currentWeatherData: weatherDataObject) {
                    
                    self?.delegate?.receiveWeatherList(list: weatherList)
                } else {
                    
                    self?.delegate?.receiveWeatherList(list: emptyWeatherData)
                }
                
            } catch {
                
                print("Error in JSON conversion")
            }
        }
        
        
        //execute the task
        task.resume()
        
        print("Task Resumed")
    }
    
    func parseWeatherData(currentWeatherData: Any) -> WeatherData {
        
        var finalWeatherList = emptyWeatherData
        
        guard let currentWeatherData = currentWeatherData as? [String: Any]
        else {
            
            return emptyWeatherData
        }
        
        /*--------------------------------------------------------------------------*/
        
        guard let timeZone = currentWeatherData[ParseDataKeys.timezone.rawValue],
              let currentTimeZone = timeZone as? Double,
              let name = currentWeatherData[ParseDataKeys.name.rawValue],
              let cityName = name as? String,
              let id = currentWeatherData[ParseDataKeys.id.rawValue],
              let cityId = id as? Int,
              let visibilityVal = currentWeatherData[ParseDataKeys.visibility.rawValue],
              let visibility = visibilityVal as? Double
        else {
            
            return emptyWeatherData
        }
        
        print("TimeZone : \(currentTimeZone)")
        print("CityName: \(cityName)")
        print("Visibility: \(visibility)")
        print("City id: \(cityId)")
        
        /*--------------------------------------------------------------------------*/
        
        guard let cordinate = currentWeatherData[ParseDataKeys.coord.rawValue],
              let cordinateValues = cordinate as? [String: Double],
              let longitude = cordinateValues[ParseDataKeys.lon.rawValue],
              let lattitude = cordinateValues[ParseDataKeys.lat.rawValue]
        else {
           
            return emptyWeatherData
        }
        
        print("Lattitude    : \(lattitude)")
        print("Longitude    : \(longitude)")
        
        /*--------------------------------------------------------------------------*/
        
        guard let main = currentWeatherData[ParseDataKeys.main.rawValue],
              let mainValues = main as? [String: Double],
              let temperature = mainValues[ParseDataKeys.temp.rawValue],
              let precipitation = mainValues[ParseDataKeys.feels_like.rawValue],
              let tempMin = mainValues[ParseDataKeys.temp_min.rawValue],
              let tempMax = mainValues[ParseDataKeys.temp_max.rawValue],
              let humidity = mainValues[ParseDataKeys.humidity.rawValue]
        else {
            
            return emptyWeatherData
        }
        
        print("Temperature    : \(temperature)")
        print("Precipitation    : \(precipitation)")
        print("Min Temperature    : \(tempMin)")
        print("Max Temperature    : \(tempMax)")
        print("Humidity    : \(humidity)")
        
        /*--------------------------------------------------------------------------*/
        
        guard let wind = currentWeatherData[ParseDataKeys.wind.rawValue],
              let windValues = wind as? [String: Double],
              let windSpeed = windValues[ParseDataKeys.speed.rawValue]
        else {
            print("1")
            return emptyWeatherData
        }
          
        print("WindSpeed    : \(windSpeed)")
        
        
        
        guard let clouds = currentWeatherData[ParseDataKeys.clouds.rawValue],
              let cloudsValues = clouds as? [String: Double],
              let allDayCloud = cloudsValues[ParseDataKeys.all.rawValue]
        else {
            
            print("2")
            return emptyWeatherData
        }
        
        print("Clouds    : \(allDayCloud)")
        
        /*--------------------------------------------------------------------------*/
        
        guard let weather = currentWeatherData[ParseDataKeys.weather.rawValue] as? [Any]
        else {
            
            print("3")
            return emptyWeatherData
        }
        
        var descript = ""
        var weatherName = ""
        
        for value in weather {
            
             if let condition = value as? [String: Any],
                let description = condition[ParseDataKeys.description.rawValue] as? String,
                let name = condition[ParseDataKeys.main.rawValue] as? String {
        
                print("Description: \(description)")
                descript = description
                weatherName = name
             } else {
                
                print("4")
             }
        }
            
        let currentDateTime = Date()

        let formatter = DateFormatter()
        formatter.dateFormat = "yy:MM:dd:HH:mm"
        
        let datetime = formatter.string(from: currentDateTime)
        let currentTime = String("\(datetime)")
        print(currentTime)
        
        let currentWeatherCondition = WeatherData(temperature: temperature, minTemp: tempMin, maxTemp: tempMax, precipitation: precipitation, humidity: humidity, wind: windSpeed, visibility: visibility, locationName: cityName, weatherDescription: descript, weatherName: weatherName, cityId: cityId, time: currentTime)
        
        finalWeatherList = currentWeatherCondition
        return finalWeatherList
    }
}

