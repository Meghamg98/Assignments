//
//  UIColor+Extension.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 09/06/21.
//

import UIKit

extension UIColor {
    
    static func statusBarColor() -> UIColor {
        
        return UIColor(red:0.53, green:0.32, blue:0.8, alpha:0.68)
    }
    
    static func selectedTempButtonColor() -> UIColor {
        
        return UIColor(red:0.89, green:0.16, blue:0.26, alpha:1)
    }
    
    static func whiteWithOpacity(opacity: CGFloat) -> UIColor {
        
        return UIColor(red:1.0, green:1.0, blue:1.0, alpha: opacity)
    }
 
    static func burgerMenuItemColor() -> UIColor {
        
        return UIColor(red:0.44, green:0.44, blue:0.44, alpha:1)
    }
    
    static func pageNameTextColor() -> UIColor {
        
        return UIColor(red:0.16, green:0.18, blue:0.2, alpha:1)
    }
    
    static func locationLabelColor() -> UIColor {
        
        return  UIColor(red:1, green:0.9, blue:0.22, alpha:1)
    }
   
}
