//
//  UIImage+Extension.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 09/06/21.
//

import UIKit

extension UIImage {
    
    static func imageFor(name: String) -> UIImage? {
        
        if let image = UIImage(named: name.lowercased()) {
            
            return image
        } else {
            
            return UIImage(named: "sunny")
        }
    }
}
