//
//  URL+Extension.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 13/06/21.
//

import Foundation

extension URL {
    
    static func favouriteListStoragePath() -> URL {
        
        let myFileManager = FileManager.default
        let myFolders = myFileManager.urls(for: .documentDirectory, in: .userDomainMask)
        let myDocumentFolder = myFolders[0]
        let filePath = myDocumentFolder.appendingPathComponent("MyFavouriteList6")
        return filePath
    }
    
    static func recentSearchListStoragePath() -> URL {
        
        let myFileManager = FileManager.default
        let myFolders = myFileManager.urls(for: .documentDirectory, in: .userDomainMask)
        let myDocumentFolder = myFolders[0]
        let filePath = myDocumentFolder.appendingPathComponent("MyRecentSearchList6")
        return filePath
    }
    
    static func tempUnitStoragePath() -> URL {
        
        let myFileManager = FileManager.default
        let myFolders = myFileManager.urls(for: .documentDirectory, in: .userDomainMask)
        let myDocumentFolder = myFolders[0]
        let filePath = myDocumentFolder.appendingPathComponent("MyTempUnit")
        return filePath
    }
}
