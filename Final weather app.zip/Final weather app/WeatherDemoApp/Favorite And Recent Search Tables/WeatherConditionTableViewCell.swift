//
//  WeatherConditionTableViewCell.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 10/06/21.
//

import UIKit

class WeatherConditionTableViewCell: UITableViewCell {

    
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var locationWeatherImage: UIImageView!
    @IBOutlet weak var temperature: UILabel!
    @IBOutlet weak var weatherCondition: UILabel!
    @IBOutlet weak var favourateButton: UIButton!
    
    override func layoutSubviews() {
        super.layoutSubviews()

        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0))
        contentView.layer.backgroundColor = UIColor.whiteWithOpacity(opacity: 0.1).cgColor
        
        locationLabel.textColor = UIColor.locationLabelColor()
        
    }

}
