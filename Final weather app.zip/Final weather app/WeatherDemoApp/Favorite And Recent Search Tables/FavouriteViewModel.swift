//
//  FavouriteViewModel.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 13/06/21.
//

import Foundation

enum TempUnit: String {

    case celcius
    case fahrenheit
}

class FavouriteViewModel {
    
    var favouriteArray = [WeatherData]()
    var recentSearchArray = [WeatherData]()
    var filteredArray = [WeatherData]()
    
    var currentTempUnit: String = "celcius"
    
    func addToFavouriteList(weatherDataObject: WeatherData) {
        
        favouriteArray.append(weatherDataObject)
        print("Added to fav list")
        print(favouriteArray.count)
        self.saveFavouriteDetails()
    }
    
    func addToRecentSearchList(weatherDataObject: WeatherData) {
        
        recentSearchArray.append(weatherDataObject)
        //searchEnumValue = .searchNotSelected
        print("Added to recent list")
        print(recentSearchArray.count)
        self.saveRecentSearchDetails()
    }
    
    func fetchRequiredCityAtIndex(index: Int, currentStatus: String) -> WeatherData? {

        var requiredArray = [WeatherData]()
        
        if currentStatus == "favourite" {
            
            requiredArray = favouriteArray
            
        } else if currentStatus == "recentSearch" {
            
            requiredArray = recentSearchArray
        } 
        if index >= 0 && index < requiredArray.count {
          
            return requiredArray[index]
        }
        return nil
    }
    
    func deleteSelectedCity(index: Int, currentStatus: String) {
        
        if currentStatus == "favourite" {
            
            favouriteArray.remove(at: index)
            self.saveFavouriteDetails()
            
        } else if currentStatus == "recentSearch"{
            
            recentSearchArray.remove(at: index)
            self.saveRecentSearchDetails()
        }
        
    }
    
    func fetchFromRecent(cityName: String) -> WeatherData {
        
        for data in recentSearchArray {
            
            let locationName = data.locationName
            
            if cityName == locationName {
                
                 return data
            }
        }
        return emptyWeatherData
    }
    
    func validate(cityId: Int) -> Bool {
        
        for data in favouriteArray {

            let locationId = data.cityId

            if locationId == cityId {

                 return true
            }
        }
        return false
    }
    
    func arrayCount(required: String) -> Int{
        
        if(required == "favourite") {
            
            return favouriteArray.count
            
        } else if (required == "recentSearch") {
            
            return recentSearchArray.count
            
        } else if (required == "selected") {
            
            return filteredArray.count
        }
        return 0
    }
    
    func searchCity(searchText: String, currentStatus: String) {
        
        print("Searching for \(searchText)")
        
        var requiredArray = [WeatherData]()
        
        if (currentStatus == "favourite") {
            
            print("favourite Array selected")
            requiredArray = favouriteArray
        } else if (currentStatus == "recentSearch") {
            
            print("Recent Array selected")
            requiredArray = recentSearchArray
        }
        
        filteredArray = requiredArray.filter({
            (WeatherData) -> Bool
            in
            WeatherData.locationName.lowercased().contains(searchText.lowercased())
        })
        
//        for data in requiredArray {
//
//            let cityName = data.locationName
//
//            if cityName.lowercased().contains(searchText.lowercased()) {
//
//                print("Result matching")
//                filteredArray.append(data)
//                print(filteredArray.count)
//            }
//        }
    }
    
    func checkingSessionExpiryTime(weatherData: WeatherData) -> Bool {
        
        let timeOfSave = weatherData.time
        let componentsOfSave = timeOfSave.components(separatedBy: ":")
        let year = componentsOfSave[0], month = componentsOfSave[1], date = componentsOfSave[2]
        
        let currentSystemTime = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yy:MM:dd:HH:mm"
        
        let currentTime = formatter.string(from: currentSystemTime)
        let timeOfLoad = String("\(currentTime)")
        let componentsOfLoad = timeOfLoad.components(separatedBy: ":")
        let currentYear = componentsOfLoad[0], currentMonth = componentsOfLoad[1], currentDate = componentsOfLoad[2]
        
        if( year == currentYear && month == currentMonth && date == currentDate) {
            
            guard let hour = Int(componentsOfSave[3]), let minute = Int(componentsOfSave[4]), let currentHour = Int(componentsOfLoad[3]), let currentMinute = Int(componentsOfLoad[4])
            else {
                return true
            }
            
            if (hour == currentHour) {
                
                if (currentMinute - minute < 30) {
                        
                    return false
                }
           
            } else if ( currentHour == hour + 1) {
                
                var minutes = currentMinute
                minutes += 60
                
                if (minutes - minute < 30) {
                        
                    return false
                }
            }
        }
        return true
    }
    
    func saveFavouriteDetails() {
        
        do{
            let weatherData = try
                NSKeyedArchiver.archivedData(withRootObject: self.favouriteArray, requiringSecureCoding: false)
            try weatherData.write(to: URL.favouriteListStoragePath())
        } catch {
            print("Path not found")
        }
    }
    
    func loadFavouriteDetails() {
        
        do{
            let weatherData = try
                Data(contentsOf: URL.favouriteListStoragePath())
            if let weather = try
                NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(weatherData) as? [WeatherData] {
                self.favouriteArray = weather
            }
        } catch {
            print("File not found")
        }
    }
    
    func saveRecentSearchDetails() {
        
        do{
            let weatherData = try
                NSKeyedArchiver.archivedData(withRootObject: self.recentSearchArray, requiringSecureCoding: false)
            try weatherData.write(to: URL.recentSearchListStoragePath())
        } catch {
            print("Path not found")
        }
    }
    
    func loadRecentSearchDetails() {
        
        do{
            let weatherData = try
                Data(contentsOf: URL.recentSearchListStoragePath())
            if let weather = try
                NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(weatherData) as? [WeatherData] {
                self.recentSearchArray = weather
            }
        } catch {
            print("File not found")
        }
    }
    
    func saveTempUnit() {
        
        do{
            let tempUnit = try
                NSKeyedArchiver.archivedData(withRootObject: self.currentTempUnit, requiringSecureCoding: false)
            try tempUnit.write(to: URL.tempUnitStoragePath())
            print("Current tempUnit: \(currentTempUnit)")
        } catch {
            print("Path not found")
        }
    }
    
    func loadTempUnit() {
        
        do{
            let tempUnit = try
                Data(contentsOf: URL.tempUnitStoragePath())
            if let tempUnit = try
                NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(tempUnit) as? String {
                self.currentTempUnit = tempUnit
                print("Current tempUnit: \(currentTempUnit)")
            }
        } catch {
            print("File not found")
        }
    }
}
