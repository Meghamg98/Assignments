//
//  WeatherViewController.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 10/06/21.
//

import UIKit

protocol WeatherTableProtocol: AnyObject {
    
    func displayWeatherFor(cityName: String, sessionExpired: Bool)
}

class WeatherViewController: UIViewController {
    
    @IBOutlet weak var pageNameLabel: UILabel!
    @IBOutlet weak var noContentLabel: UILabel!
    
    @IBOutlet weak var emptyContentView: UIView!
    @IBOutlet weak var tableViewContainer: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var leftLabel:
        RobotoMediumWhiteLabels!
    @IBOutlet weak var rightButton: UIButton!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var favouriteModel = FavouriteViewModel()
    
    weak var weatherTableDelegate: WeatherTableProtocol?
    var currentStatus: Status = .favourite
    var currentSearchStatus: SearchStatus = .notSelected
    var isCelciusSelected = true
    
    /*
    var favouriteArrayCount: Int {
        
        return favouriteModel.favouriteArray.count
    }
    
    var recentSearchArrayCount: Int {
        
        return favouriteModel.recentSearchArray.count
    }
    
    var filterArrayCount: Int {
        
        return favouriteModel.filteredArray.count
    }
    */
    
    override func viewDidLoad() {
        
        //print("ViewDidLoad appeared")
        
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        self.tableView.rowHeight = 80
        self.searchView.isHidden = true
        self.searchBar.delegate = self
        
        if (currentStatus == .favourite) {
            
            favouriteModel.filteredArray =  favouriteModel.favouriteArray
            pageNameLabel.text = "Favourite"
            
            let favCount = favouriteModel.arrayCount(required: "favourite")
            if (favCount != 0){
                
                self.emptyContentView.isHidden = true
                self.tableViewContainer.isHidden = false
                leftLabel.text = "\(favCount) City added as favourite"
                rightButton.setTitle("Remove All", for: .normal)
            } else {
                
                noContentLabel.text = "No Favourites added"
                self.tableViewContainer.isHidden = true
            }
            
        } else if (currentStatus == .recentSearch) {
            
            pageNameLabel.text = "Recent Search"
            favouriteModel.filteredArray =  favouriteModel.recentSearchArray
            let recentCount = favouriteModel.arrayCount(required: "recentSearch")
            
            if (recentCount != 0){
                
                self.emptyContentView.isHidden = true
                self.tableViewContainer.isHidden = false
                leftLabel.text = "You recently searched for"
                rightButton.setTitle("Clear All", for: .normal)
            } else {
                
                noContentLabel.text = "No Recent Search"
                self.tableViewContainer.isHidden = true
            }
        }
    
    }
    
    override func viewDidLayoutSubviews() {
       
        self.tableView.reloadData()
        
        if let view = view as? CustomBackgroundImage {
            
            view.backgroundLayer.frame = self.view.bounds
        }
        
        //self.tableView.reloadData()
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    func currentTableCount() -> Int {
        
        if currentSearchStatus == .selected {
            
            return favouriteModel.arrayCount(required: "selected")
        } else {
            
            if currentStatus == .favourite {
            
                return favouriteModel.arrayCount(required: "favourite")
                
            } else if currentStatus == .recentSearch {
                
                return favouriteModel.arrayCount(required: "selected")
            }
        }
        return 0
    }
    
    
    @IBAction func removeAllClicked(_ sender: Any) {
        
        if currentStatus == .favourite {
            
            let alert = UIAlertController(title: "Are you sure want to remove all the favourites?", message: "", preferredStyle:.alert)
               
            alert.addAction(UIAlertAction(title: "YES", style: .default, handler: {
                (action) -> Void
                in
                   
                self.favouriteModel.favouriteArray.removeAll()
                self.noContentLabel.text = "No Favourites added"
                self.tableViewContainer.isHidden = true
                self.emptyContentView.isHidden = false
                self.favouriteModel.saveFavouriteDetails()
               }))
            
            alert.addAction(UIAlertAction(title: "NO", style: .default, handler: nil))
               
            self.present(alert, animated: true, completion: nil)
            
            favouriteModel.saveFavouriteDetails()
             
        } else if currentStatus == .recentSearch {
            
            favouriteModel.recentSearchArray.removeAll()
            self.noContentLabel.text = "No Recent Search"
            self.tableViewContainer.isHidden = true
            self.emptyContentView.isHidden = false
            
            favouriteModel.saveRecentSearchDetails()
        }
        
        self.tableView.reloadData()
    }
    
    @IBAction func searchButtonTapped(_ sender: Any) {
        
        self.searchView.isHidden = false
        self.currentSearchStatus = .selected
    }
 
    @IBAction func favouriteButtonUncheck(_ sender: Any) {
        
        print("Fav button unchecked")
        
        if currentStatus == .favourite {
            
            favouriteModel.deleteSelectedCity(index: (sender as AnyObject).tag, currentStatus: currentStatus.rawValue)
            let count = favouriteModel.arrayCount(required: "favourite")
            leftLabel.text = "\(count) City added as favourite"
            //tableView.reloadData()
            
            favouriteModel.saveFavouriteDetails()
            
        } else if currentStatus == .recentSearch {
            
            if let favourite = (sender as AnyObject) as? FavoriteButtonToggle {

                favourite.toggle()
            }
            
            self.tableView.reloadData()
            
            let currentData = favouriteModel.recentSearchArray[(sender as AnyObject).tag]
            print(currentData.locationName)
            
            let isPresent = favouriteModel.validate(cityId: currentData.cityId)
            
            if isPresent == true {
                
                favouriteModel.favouriteArray.remove(at: (sender as AnyObject).tag)
            } else {
                
                favouriteModel.addToFavouriteList(weatherDataObject: currentData)
            }
            
            favouriteModel.saveRecentSearchDetails()
        }
    }
}

extension WeatherViewController: UISearchBarDelegate {
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        self.searchView.isHidden = true
        self.currentSearchStatus = .notSelected
        
        searchBar.text = ""
        searchBar.resignFirstResponder()
        
        self.tableView.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        favouriteModel.filteredArray = []
        var requiredArray = [WeatherData]()
        
        if currentStatus == .favourite {
            
            requiredArray = favouriteModel.favouriteArray
            
        } else if currentStatus == .recentSearch {
            
            requiredArray = favouriteModel.recentSearchArray
        }
        
        if(searchText == "") {
            
            print("Empty Text")
            favouriteModel.filteredArray = requiredArray
            
        } else {
            print("Entering Text")
            favouriteModel.searchCity(searchText: searchText, currentStatus: currentStatus.rawValue)
        }
        self.tableView.reloadData()
    }
}

extension WeatherViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "WeatherConditionCell", for: indexPath) as? WeatherConditionTableViewCell {
           
            var weatherCondition = emptyWeatherData
            
            if currentSearchStatus == .selected {
                
                print("Search Selected")
                weatherCondition = favouriteModel.filteredArray[indexPath.row]
                
            } else if let weatherDetails = favouriteModel.fetchRequiredCityAtIndex(index: indexPath.row, currentStatus: self.currentStatus.rawValue) {
                
                print("Search Not Selected")
                weatherCondition = weatherDetails
            }
            
            if currentStatus == .favourite {
                
                cell.favourateButton.setBackgroundImage(UIImage(named: "icon_favourite_active"), for: .normal)
                
            } else {

                let isPresent = favouriteModel.validate(cityId: weatherCondition.cityId)

                if isPresent == true {

                    cell.favourateButton.setBackgroundImage(UIImage(named: "icon_favourite_active"), for: .normal)

                } else {

                    cell.favourateButton.setBackgroundImage(UIImage(named: "icon_favourite"), for: .normal)
                }
            }
            
            cell.locationLabel.text = weatherCondition.locationName
            cell.locationWeatherImage.image = UIImage.imageFor(name: weatherCondition.weatherName)
            
            if favouriteModel.currentTempUnit == "celcius" {
                
                cell.temperature.text = String("\(Int(weatherCondition.temperature))°C")
            } else {
                
                let toFah = weatherCondition.temperature * 9 / 5 + 32
                cell.temperature.text = String("\(Int(toFah))°F")
            }
            
            cell.weatherCondition.text = weatherCondition.weatherDescription
            cell.favourateButton.tag = indexPath.row
            
            return cell
        }
        
        favouriteModel.saveFavouriteDetails()
        favouriteModel.saveRecentSearchDetails()
        
        return WeatherConditionTableViewCell()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.currentTableCount()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print("Selected \(indexPath.row)")
        if let weatherData = favouriteModel.fetchRequiredCityAtIndex(index: indexPath.row, currentStatus: currentStatus.rawValue) {
        
            let isSessionExpired = favouriteModel.checkingSessionExpiryTime(weatherData: weatherData)
            
            self.weatherTableDelegate?.displayWeatherFor(cityName: weatherData.locationName, sessionExpired: isSessionExpired)
        }
        self.navigationController?.popViewController(animated: false)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
        
            if currentStatus == .favourite {
                
                favouriteModel.favouriteArray.remove(at: indexPath.row)
                
            } else if currentStatus == .recentSearch {
                
                favouriteModel.recentSearchArray.remove(at: indexPath.row)
            }
            
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
        
        let count = favouriteModel.arrayCount(required: "favourite")
        leftLabel.text = "\(count) City added as favourite"
        tableView.reloadData()
    }
}

