//
//  CustomBackgroundImage.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 09/06/21.
//

import UIKit

class CustomBackgroundImage: UIView {

    var backgroundLayer = UIImageView()
    //let statusBarView = UIView(frame: UIApplication.shared.statusBarFrame)
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.setBackgroundView()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.setBackgroundView()
    }
    
    func setBackgroundView() {
        
        backgroundLayer = UIImageView(frame: self.bounds)
        backgroundLayer.image = UIImage(named: "backgroundImage")
        self.insertSubview(backgroundLayer, at: 0)
        
    }
}

