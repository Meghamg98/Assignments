//
//  CustomDateAndTime.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 15/06/21.
//

import Foundation
import UIKit

class CustomDateAndTime: UILabel {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.dateAndTimeProperty()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.dateAndTimeProperty()
    }
    
    func dateAndTimeProperty() {
        
        self.textColor = UIColor.whiteWithOpacity(opacity: 0.6)
        self.font = UIFont(name: "Roboto-Regular", size: 13.0)
        
        let currentDateTime = Date()

        let formatter = DateFormatter()
        formatter.dateFormat = "E,  d  MMM  yyyy   h:mm a"
        
        let datetime = formatter.string(from: currentDateTime).uppercased()
        self.text = String("\(datetime)")
        
    }
}
