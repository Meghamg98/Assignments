//
//  CustomMenuButtons.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 11/06/21.
//

import UIKit

class CustomMenuButtons: UIButton {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.buttonProperty()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.buttonProperty()
    }
    
    func buttonProperty() {
        
        self.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 14.0)
        self.titleLabel?.textColor = UIColor.burgerMenuItemColor()
        
    }
}
