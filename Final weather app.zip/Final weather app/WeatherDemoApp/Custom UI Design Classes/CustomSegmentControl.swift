//
//  CustomSegmentControl.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 18/06/21.
//

import Foundation
import UIKit

class CustomSegmentControl: UISegmentedControl {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.segmentProperty()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.segmentProperty()
    }
    
    func segmentProperty() {
        
        self.layer.cornerRadius = 1
        self.layer.borderColor = UIColor.white.cgColor
        self.layer.borderWidth = 1
        self.layer.masksToBounds = true

        let normalColor = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.setTitleTextAttributes(normalColor, for: .normal)
        
        let selectedColor = [NSAttributedString.Key.foregroundColor: UIColor.selectedTempButtonColor()]
        self.setTitleTextAttributes(selectedColor, for: .selected)
    }
}
