//
//  RobotoMediumWhiteLabels.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 10/06/21.
//

import Foundation
import UIKit

class RobotoMediumWhiteLabels: UILabel {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.labelProperty()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.labelProperty()
    }
    
    func labelProperty() {
        
        self.textColor = UIColor.white
        
        //let fontSize = self.font.pointSize;
        //self.font = UIFont(name: "Roboto-Medium", size: fontSize)
    }
}
