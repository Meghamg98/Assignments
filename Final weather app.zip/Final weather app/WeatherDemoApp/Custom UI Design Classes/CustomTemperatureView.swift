//
//  CustomTemperatureView.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 13/06/21.
//

import UIKit

class CustomTemperatureView: UIView {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.temperatureViewProperty()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.temperatureViewProperty()
    }
    
    func temperatureViewProperty() {
        
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.white.cgColor
    }
}
