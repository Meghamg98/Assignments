//
//  ConstantValues.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 11/06/21.
//

import Foundation
import  UIKit

enum Status: String {
    
    case favourite
    case recentSearch
}

enum SearchStatus: String {
    
    case selected
    case notSelected
}

enum WeatherDataKeys: String {
    
    case temperature = "temperature"
    case minTemp = "minTemp"
    case maxTemp = "maxTemp"
    case precipitation = "precipitation"
    case humidity = "humidity"
    case wind = "wind"
    case visibility = "visibility"
    case locationName = "locationName"
    case weatherDescription = "weatherDescription"
    case weatherName = "weatherName"
    case cityId = "cityId"
    case time = "time"
}

enum SearchEnum: String {
    
    case searchSelected
    case searchNotSelected
}
var searchEnum: SearchEnum = .searchNotSelected

enum ParseDataKeys: String {
    
    case timezone = "timezone"
    case name = "name"
    case id = "id"
    case visibility = "visibility"
    case coord = "coord"
    case lon = "lon"
    case lat = "lat"
    case main = "main"
    case temp = "temp"
    case feels_like = "feels_like"
    case temp_min = "temp_min"
    case temp_max = "temp_max"
    case humidity = "humidity"
    case wind = "wind"
    case speed = "speed"
    case clouds = "clouds"
    case all = "all"
    case weather = "weather"
    case description = "description"
}

var imageArray = [UIImage(named: "icon_temperature_info"),
                  UIImage(named: "icon_precipitation_info"),
                  UIImage(named: "icon_humidity_info"),
                  UIImage(named: "icon_wind_info"),
                  UIImage(named: "icon_visibility_info")
                ]
var conditionArray = ["Min - Max", "Precipitation", "Humidity", "Wind", "Visibility"]

let emptyWeatherData = WeatherData(temperature: 0.0, minTemp: 0.0, maxTemp: 0.0, precipitation: 0.0, humidity: 0.0, wind: 0.0, visibility: 0.0, locationName: "", weatherDescription: "", weatherName: "", cityId: 0, time: "")
