//
//  FavoriteButtonToggle.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 09/06/21.
//

import UIKit
import Foundation

class FavoriteButtonToggle: UIButton {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.toggleButtonProperty()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.toggleButtonProperty()
    }
    
    func toggleButtonProperty() {
        
        self.setImage(UIImage(named: "icon_favourite"), for: .normal)
        self.setImage(UIImage(named: "icon_favourite_active"), for: .selected)
        
        self.isSelected = false
        
    }
    
    //@objc
    func toggle() {
        
        self.isSelected = !self.isSelected
    }
}
