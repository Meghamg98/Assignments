//
//  CustomTemperatureButton.swift
//  WeatherDemoApp
//
//  Created by Megha M Gamskar on 13/06/21.
//

import UIKit

class CustomTemperatureButton: UIButton {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.setCustomButtonProperties()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.setCustomButtonProperties()
    }
    
    func setCustomButtonProperties() {
        
        self.setTitleColor(UIColor.selectedTempButtonColor(), for: .selected)
        self.setTitleColor(UIColor.white, for: .normal)
        
        self.backgroundColor = UIColor.white
    }
}
